package com.example.finalproject;

public class User {
    private String Username;
    public User(String username) {
        Username = username;
    }
    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }


}
